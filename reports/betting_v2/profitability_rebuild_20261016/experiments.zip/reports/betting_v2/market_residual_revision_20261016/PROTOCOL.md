# Signed market-residual calibration, 16 October 2026

Follow-up proposed after the preceding convex-pool diagnostic assigned zero statistical weight to FT goals in all three prior windows. This is a new development hypothesis, not an untouched test.

Fit the normalized complete-partition distribution `softmax(log(q_market) + beta*(log(p_stat)-log(q_market)) + gamma*log(q_market))`. The statistical deviation can have a negative coefficient if earlier outcomes support it. This is learned from a proper multiclass probability score; do not manually reverse previously losing bets or fit ROI.

Fixed settings: beta in [-1,1], gamma in [-.5,.5], penalty .01*(beta^2+gamma^2), at least 30 preceding fixtures. Give each fixture total weight one regardless of the number of bookmaker partitions. The no-data state uses beta=gamma=0. Preserve complete-partition normalization, chronological monthly CSV folds, and the receipt study's at-least-24-hour daily outcome lag. Reuse the exact frozen event frames from market_decision_revision_20261016; no core refit or provider request.

Compare the existing odds limits and 60% probability floor to a separately labelled positive-EV diagnostic without that floor. Rank by EV/probability, favourite only as a tie break, one broad family per fixture. Report every result and prior coefficient; do not choose the profitable policy or market after evaluating returns. No app deployment or threshold change is authorized by this experiment's output alone. Per-partition calibrated probabilities are research diagnostics rather than a coherent live replacement of the full joint count PMF. Integer-line push probability remains the separately forecast statistical push probability. Price execution and previously inspected periods remain limitations.
